package com.cg.billpaymentmvc.service;

import com.cg.billpaymentmvc.dto.Customer;

/*
 * 
 Connection Service Interface Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */


public interface ConnectionService {


	public Customer add(Customer customer);

	
	
}
