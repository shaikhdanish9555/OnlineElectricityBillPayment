package com.cg.billpaymentmvc.service;

import com.cg.billpaymentmvc.dto.*;
import java.math.BigDecimal;
import java.math.BigInteger;

import com.cg.billpaymentmvc.dto.Transaction;
import com.cg.billpaymentmvc.exceptions.WalletException;

/*
 * 
 Transaction Service Interface Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */


public interface TransactionService {
	
	public Transaction lastTransaction(Transaction consumerNumber);
	//public Transaction getTransaction() throws WalletException;
}
