package com.cg.billpaymentmvc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.billpaymentmvc.dao.ConnectionDao;
import com.cg.billpaymentmvc.dao.ConnectionDaoImp;
import com.cg.billpaymentmvc.dto.Customer;


/*
 * 
 Connection Service Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

@Service("connectionService")
@Transactional
public class ConnectionServiceImp implements ConnectionService {

@Autowired
ConnectionDaoImp dao;
	    
	    public ConnectionServiceImp()
	    {
	    	 
	    }
		
	    
	    //Add the Customer Details and save them 
	    /*
	     * 
	     Connection Service Class implemented by 
	     @Author: Danish Shaikh
	     @Version:1.0
	     @Since: 11-05-2019
	     */
	    
	    public Customer add(Customer customer) {
		// TODO Auto-generated method stub
		return dao.save(customer);
	}
	
	
	
	

/*    ConnectionDaoImp dao;
    
    public ConnectionServiceImp()
    {
    	dao=new ConnectionDaoImp();
    }
	

	public Customer add(Customer customer) {
		// TODO Auto-generated method stub
	
		return dao.save(customer);
	}
*/
	

}
