package com.cg.billpaymentmvc.service;

import com.cg.billpaymentmvc.dao.TransactionDaoImp;
import com.cg.billpaymentmvc.dto.*;
import com.cg.billpaymentmvc.exceptions.WalletException;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


/*
 * 
 Transaction Service Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */


@Service("transactionservice")
@Transactional
public class TransactionServiceImp implements TransactionService{

@Autowired
TransactionDaoImp dao;
    	
/*
 * 
 Transaction Service Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

	

		public Transaction lastTransaction(Transaction consumerNumber) { //Method for Last Transaction
			// TODO Auto-generated method stub
			return dao.lastTransactionOne(consumerNumber) ;
		}

		
		//Get the Details of the Last Transaction and throws an Exception
		/*
		 * 
		 Transaction Service Class implemented by 
		 @Author: Danish Shaikh
		 @Version:1.0
		 @Since: 11-05-2019
		 */
		
		public Transaction getTransaction() throws WalletException
		{
			Transaction obj=dao.getTransaction();
			if(obj==null)
			{
				throw new WalletException(" Transaction Does Not Exist....!!!!");
			}
			else
			{
				return obj;
			}
			
		}
    	
}
