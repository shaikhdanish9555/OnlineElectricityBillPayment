package com.cg.billpaymentmvc.service;

import java.math.BigDecimal;

import com.cg.billpaymentmvc.dto.Wallet;
import com.cg.billpaymentmvc.exceptions.WalletException;

/*
 * 
 Wallet Service Interface Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */


public interface WalletService {
	
	public Wallet addMoney(Wallet ad);
	
	public Wallet showBalance(int id);
}
