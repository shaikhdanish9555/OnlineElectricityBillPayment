package com.cg.billpaymentmvc.service;

import com.cg.billpaymentmvc.dao.WalletDaoImp;
import com.cg.billpaymentmvc.dto.*;
import com.cg.billpaymentmvc.exceptions.WalletException;

import java.math.BigDecimal;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/*
 * 
 Wallet Service Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

@Service("walletservice")
@Transactional
public class WalletServiceImp implements WalletService{

	
	
	@Autowired
	private WalletDaoImp da;
	
	public WalletServiceImp() {
		
		da=new WalletDaoImp();
	}

	
	//Adding Money to the Wallet
	/*
	 * 
	 Wallet Service Class implemented by 
	 @Author: Danish Shaikh
	 @Version:1.0
	 @Since: 11-05-2019
	 */
	
	public Wallet addMoney(Wallet ad) {
		// TODO Auto-generated method stub
		return da.saveWallet(ad);
	}

	
	/*
	 * 
	 Wallet Service Class implemented by 
	 @Author: Danish Shaikh
	 @Version:1.0
	 @Since: 11-05-2019
	 */
	
	
	public Wallet showBalance(int id) { //Show the Available Balance of the Wallet
		// TODO Auto-generated method stub
		/*Wallet wall=da.showTopupbalance(id);
		if(wall!=null)
		{
			return wall;	
			
		}
		else
		{
			System.out.println("Balance is Not Available");	
		}*/
		return da.showTopupbalance(id);
	}

}
