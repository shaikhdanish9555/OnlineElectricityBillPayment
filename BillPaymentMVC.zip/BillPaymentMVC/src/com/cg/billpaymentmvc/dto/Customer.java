package com.cg.billpaymentmvc.dto;

import java.math.BigInteger;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billpaymentmvc.dto.Connection;


/*
 * 
 Customer DTO Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

@Entity
public class Customer {
	
	 
	private String name;
	@Id 
	private String contact;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="contact")
	private List<Connection> connection;
	
	
	
	public Customer()
	{
		
	}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public List<Connection> getConnection() {
		return connection;
	}

	public void setConnection(List<Connection> connection) {
		this.connection = connection;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", contact=" + contact + ", connection=" + connection + "]";
	}
	
	


}





/*
@Component
public class Customer {
	
	private String name;
	private BigInteger contact;
	@Autowired
	private List<Connection> connection;
	
	
	
	public Customer()
	{
		
	}
	
	
	public Customer(String name, BigInteger contact, List<Connection> connection) {
		super();
		this.name = name;
		this.contact = contact;
		this.connection = connection;
	}
	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getContact() {
		return contact;
	}

	public void setContact(BigInteger contact) {
		this.contact = contact;
	}

	public List<Connection> getConnection() {
		return connection;
	}

	public void setConnection(List<Connection> connection) {
		this.connection = connection;
	}


	@Override
	public String toString() {
		return "Customer [name=" + name + ", contact=" + contact + ", connection=" + connection + "]";
	}


}

*/
