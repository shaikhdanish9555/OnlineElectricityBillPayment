package com.cg.billpaymentmvc.dto;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.springframework.stereotype.Component;

import com.cg.billpaymentmvc.dto.Connection;
import com.cg.billpaymentmvc.dto.Customer;


/*
 * 
 Transaction DTO Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

@Entity
public class Transaction {
	
	@Id
    private int id; 
	
	private BigDecimal amount;
	@OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="trans_id")
	private List<Connection> connection;
	//private List<com.cg.billpaymentmvc.dto.Connection> connection;
	public List<Connection> getConnection() {
		return connection;
	}


	public void setConnection(List<Connection> connection) {
		this.connection = connection;
	}


	public Transaction()
	{
		
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public BigDecimal getAmount() {
		return amount;
	}


	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
}




/*@Component
public class Transaction {
	
	private Customer customer;
	private List<Connection> connection;
	private BigDecimal amount;
	
	
	public Transaction()
	{
		
	}


	public Transaction(Customer customer, List<Connection> connection, BigDecimal amount) {
		super();
		this.customer = customer;
		this.connection = connection;
		this.amount = amount;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public List<Connection> getConnection() {
		return connection;
	}


	public void setConnection(List<Connection> connection) {
		this.connection = connection;
	}


	public BigDecimal getAmount() {
		return amount;
	}


	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}


	@Override
	public String toString() {
		return "Transaction [customer=" + customer + ", connection=" + connection + ", amount=" + amount + "]";
	}
	
	
}

*/
