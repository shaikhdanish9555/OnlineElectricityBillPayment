package com.cg.billpaymentmvc.dto;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billpaymentmvc.dto.Customer;

import com.cg.billpaymentmvc.dto.Transaction;



/*
 * 
 Wallet DTO Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

@Entity
public class Wallet {
	@Id
    private int id;
 
	private BigDecimal balance;
	@OneToOne
	@JoinColumn(name="contact")
	private Customer customer;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="wallet_id")
	private List<Transaction> transaction;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<Transaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() {
		return "Wallet [id=" + id + ", balance=" + balance + ", customer=" + customer + ", transaction=" + transaction
				+ "]";
	}
	 
}



/*@Component
public class Wallet {

	private BigDecimal balance;
	@Autowired
	private Customer customer;
	@Autowired
	private Transaction transaction;
	

	public Wallet()
	{
				
	}
	

	public Wallet(BigDecimal balance, Customer customer) {
		super();
		this.balance = balance;
		this.customer = customer;
	}


	public Wallet(BigDecimal balance, Customer customer, Transaction transaction) {
		super();
		this.balance = balance;
		this.customer = customer;
		this.transaction = transaction;
	}


	public BigDecimal getBalance() {
		return balance;
	}


	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public Transaction getTransaction() {
		return transaction;
	}


	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}


	@Override
	public String toString() {
		return "Wallet [balance=" + balance + ", customer=" + customer + ", transaction=" + transaction + "]";
	}
			

}

*/