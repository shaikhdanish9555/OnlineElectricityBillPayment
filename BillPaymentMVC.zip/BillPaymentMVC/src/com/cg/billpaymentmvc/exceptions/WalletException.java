package com.cg.billpaymentmvc.exceptions;

public class WalletException extends Exception {
	public WalletException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public WalletException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
