package com.cg.billpaymentmvc.dao;
import com.cg.billpaymentmvc.dao.ConnectionDao;
import com.cg.billpaymentmvc.dto.Customer;
import com.cg.billpaymentmvc.dto.*;
import com.cg.billpaymentmvc.util.DBUtil;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;


/*
 * 
 Connection Dao Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */



@Repository("dao") //@Repository annotates classes at the persistence layer, which will act as a database repository
public class ConnectionDaoImp implements ConnectionDao{
    @PersistenceContext
	EntityManager entitymanager;
	
   
	
	public Customer save(Customer customer) {
		// TODO Auto-generated method stub
		
		entitymanager.persist(customer);
		entitymanager.flush();
		return customer;
		}

	}

		//Saving the Customers those are Added

		/*public ConnectionDaoImp()
  		{
	  	em=DBUtil.getConnection();
	 	}
		 */
		//Starting the Transaction Service
		//em.getTransaction().begin();

		//Saving the Customer Info
		//Ending the Transaction Service
		//	em.getTransaction().commit();
		
		//Closing the Connection for Entity Manager
		 
		//Closing the Connection for Entity Manager Factory
		 
	








































/*
public class ConnectionDaoImp implements ConnectionDao {
//List<Customer> cust;

	
	//Save the Details of the Customer
	
	 * 
	 Connection Dao Class implemented by 
	 @Author: Danish Shaikh
	 @Version:1.0
	 @Since: 11-05-2019
	 

	
	public Customer save(Customer customer) {
		// TODO Auto-generated method stub
		//DBUtil.customerData.add(customer);
		return customer;
	}

}


public ConnectionDaoImp()
{
	//cust=new ArrayList<Customer>();
}
*/