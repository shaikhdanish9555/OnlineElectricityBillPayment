package com.cg.billpaymentmvc.dao;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.billpaymentmvc.dao.WalletDao;
import com.cg.billpaymentmvc.dto.Wallet;
import com.cg.billpaymentmvc.exceptions.WalletException;
import com.cg.billpaymentmvc.dto.*;
import com.cg.billpaymentmvc.util.DBUtil;


@Repository("da") //@Repository annotates classes at the persistence layer, which will act as a database repository
public class WalletDaoImp implements WalletDao{
	 
	@PersistenceContext
	EntityManager entitymanager;
	/*public WalletDaoImp()
	{
		em=DBUtil.getConnection();
	}
*/
	public Wallet saveWallet(Wallet wall) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		//try {
				
				//em.getTransaction().begin();
				
			entitymanager.persist(wall);
			entitymanager.flush();
			return wall;
			//em.getTransaction().commit();
				
				
		
		/*catch(IllegalStateException e1)
		{
			System.out.println("Add the customer first");
			
		}
				 
		return null;*/
	}

	//public Wallet showTopupbalance(Wallet id) throws WalletException {
		 
		//Starting the Transaction Service 
	/*	em.getTransaction().begin();	    
		 
		 Wallet wallet= em.find(Wallet.class, id);
		 
		//Ending the Transaction Service
		 em.getTransaction().commit();
		 
		*/
		
		
	//}

	@Override
	public Wallet showTopupbalance(int id) {
		// TODO Auto-generated method stub
		return  entitymanager.find(Wallet.class, id);
	}

	public Wallet addMoney(Wallet wallet) {
		// TODO Auto-generated method stub
		entitymanager.persist(wallet);
		entitymanager.flush();
		return wallet;
	}
		
	
}
	





































/*public class WalletDaoImp implements WalletDao{
	

	//Saving Money into the Wallet
	
	 * 
	 Wallet Dao Class implemented by 
	 @Author: Danish Shaikh
	 @Version:1.0
	 @Since: 11-05-2019
	 
	
	public Wallet saveWallet(Wallet ad) {
		DBUtil.walletData.add(ad);
		return ad;
	}

	//Show the Balance Available
	
	 * 
	 Wallet Dao Class implemented by 
	 @Author: Danish Shaikh
	 @Version:1.0
	 @Since: 11-05-2019
	 
	
	public Wallet showTopupbalance() {
		if(DBUtil.walletData.isEmpty())
		{
			return null;
		}
		else {
		     
		for(Wallet wal:DBUtil.walletData) {
			
				return wal;
		}
		return null;
		}
		
		
		}
	}
	*/


/*public Wallet save(Wallet wallet) {

Wallet wall = DBUtil.getwalletData();

String query_insert = "Insert into wallet balance(?)";
PreparedStatement pstm = null;

try {
	pstm = wall.preparedStatement(query_insert);
	pstm.setBigDecimal(0, null);
	
	pstm.executeUpdate();
}
catch(SQLException e) {
	e.printStackTrace();
}

finally {
	try {
		pstm.close();
		
	}
	catch(SQLException e) {
	
	}		
}
	return null;
	
}*/







