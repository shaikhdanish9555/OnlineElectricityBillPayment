package com.cg.billpaymentmvc.dao;
import com.cg.billpaymentmvc.dto.*;


/*
 * 
 Connection Dao Interface Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

public interface ConnectionDao {
	
	public Customer save(Customer customer);
}
