package com.cg.billpaymentmvc.dao;
import com.cg.billpaymentmvc.dto.*;
import java.math.BigInteger;

/*
 * 
 Transaction Dao Interface Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */


public interface TransactionDao {

	public Transaction lastTransactionOne(Transaction consumerNumber);
	public Transaction getTransaction();
}
