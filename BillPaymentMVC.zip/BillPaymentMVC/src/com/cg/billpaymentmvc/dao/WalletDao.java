package com.cg.billpaymentmvc.dao;
import com.cg.billpaymentmvc.dto.*;
import java.math.BigDecimal;

/*
 * 
 Wallet Dao Interface Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */


public interface WalletDao {

	public Wallet saveWallet(Wallet  ad);
	public Wallet showTopupbalance(int id);
	public Wallet addMoney(Wallet wallet);
}
