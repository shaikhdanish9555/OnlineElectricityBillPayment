package com.cg.billpaymentmvc.dao;
import com.cg.billpaymentmvc.dao.TransactionDao;
import com.cg.billpaymentmvc.dto.Transaction;
import com.cg.billpaymentmvc.dto.Wallet;
import com.cg.billpaymentmvc.dto.*;
import com.cg.billpaymentmvc.util.DBUtil;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


/*
 * 
 Transaction Dao Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

@Repository
public class TransactionDaoImp implements TransactionDao  {
	
	
	@PersistenceContext
	EntityManager entitymanager;
	
	List<Transaction> mylist= new ArrayList<Transaction>();

	private Transaction transaction;
	

	/*public TransactionDaoImp()
	{
		em=DBUtil.getConnection();
	}*/
	

	@Override
	public Transaction lastTransactionOne(Transaction consumerNumber) {
		// TODO Auto-generated method stub
		
		 // List<Transaction> mylist= transaction.getTransaction();
		   for(Transaction obj:mylist)
		   {
		Query query=entitymanager.createNativeQuery("insert into transaction values(?,?,?)");
		query.setParameter(1, obj.getId());
		query.setParameter(2, obj.getAmount());
		query.setParameter(3, transaction.getId());
		query.executeUpdate();
		   }
		return consumerNumber;
		   }
	
	public Transaction getTransaction(BigInteger mobileNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Transaction getTransaction() {
		// TODO Auto-generated method stub
		return null;
	}
}
	


/*
@Repository("transactionDao") //@Repository annotates classes at the persistence layer, which will act as a database repository
public class TransactionDaoImp implements TransactionDao  {
	
	
	//Show Last Transaction Performed
	
	 * 
	 Transaction Dao Class implemented by 
	 @Author: Danish Shaikh
	 @Version:1.0
	 @Since: 11-05-2019
	 


	public Transaction lastTransactionOne(Transaction consumerNumber) {
		
		//DBUtil.transactionData.add(consumerNumber);
		return consumerNumber;
	}
	
	
	//Get The Transaction Details
	
	 * 
	 Transaction Dao Class implemented by 
	 @Author: Danish Shaikh
	 @Version:1.0
	 @Since: 11-05-2019
	 

	public Transaction getTransaction()
	{
		if(DBUtil.transactionData.isEmpty())
		{
			return null;
		}
		else {
		     for(Transaction obj:DBUtil.transactionData)
	         return obj;
		
		}
		return null;
	
	}

	}
*/