package com.cg.billpaymentmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billpaymentmvc.dto.Customer;
import com.cg.billpaymentmvc.dto.Transaction;
import com.cg.billpaymentmvc.dto.Wallet;
import com.cg.billpaymentmvc.service.ConnectionService;
import com.cg.billpaymentmvc.service.TransactionService;
import com.cg.billpaymentmvc.service.WalletService;


@Controller
public class MyController {
	
@Autowired	
private ConnectionService connectionservice;
@Autowired
private  WalletService  walletservice;
Wallet wallet1;
private Customer Customer;

	@Autowired
	 TransactionService transactionservice;

	
	@GetMapping("start")	
	public String loginPage()
	{
		return "listpage";
	}
	
	@GetMapping("addpage")
	public ModelAndView getCustomer(@ModelAttribute("cust") Customer customer) {
		
		return new ModelAndView("addcustomer");
		
	}
	
	@PostMapping("addcustomer")
	public ModelAndView addCustomer(@ModelAttribute("cust") Customer customer) {
		 
		this.Customer=customer;
		Customer customerOne = connectionservice.add(customer);
		return new ModelAndView("success_customer","key",customerOne);
	}
	
	@GetMapping("topupbalance")
	public ModelAndView getbalance(@ModelAttribute("wall") Wallet wallet) {
		
		return new ModelAndView("addmoney");
		
	}
	
	@PostMapping("addmoney")
	public ModelAndView addmoney(@ModelAttribute("wall") Wallet wallet) {
		 
		this.wallet1=wallet;
		walletservice.addMoney(wallet);
		//System.out.println(walletoone);
		return new ModelAndView("success_money","key",wallet);
	}
	
	@GetMapping("showmoney")
	public ModelAndView showmoney(@ModelAttribute("wall") Wallet wallet) {
		
		return new ModelAndView("showbalance");
		
	}
	
	@PostMapping("showbalance")
	public ModelAndView showbalance(@ModelAttribute("wall") Wallet wallet) {
		 
		Wallet walletOne = walletservice.showBalance(wallet.getId());
		return new ModelAndView("success_balance","key",walletOne);
	}
	
	
	@GetMapping("payyourbills")
	public ModelAndView getbill(@ModelAttribute("wall") Wallet wallet) {
		
		return new ModelAndView("paybills");
		
	}
	
	@PostMapping("addpaybills")
	public ModelAndView addbill(@ModelAttribute("wall") Wallet wallet) {
		List<Transaction> trans=wallet.getTransaction();
		for(Transaction tran1:trans)
		transactionservice.lastTransaction(tran1);
		
		
		return new ModelAndView("success_pay"); 
		 
	}

/*
	@GetMapping("login")
    public String loginPage()
	{
		return "mylogin";
	}*/
	/*@PostMapping("checklogin")
	public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass)
	{
		System.out.println("check login");
		if(user.equals("admin") && pass.equals("1234"))
		{
			return "listpage";
		}
		else
		{
		return  "error";
		}
		
	}
	@GetMapping("addpage")
	public ModelAndView getAddProduct(@ModelAttribute("prod") Product pro)
	
	{
		List<String> listofcategory=new ArrayList<String>();
		listofcategory.add("electronics");
		listofcategory.add("grocery");
		listofcategory.add("cloths");
		return new ModelAndView("addproduct");
	}
	@GetMapping("showpage")
	public ModelAndView showProduct()
	{
		List<Product> myAllProduct= service.showAll();
		 
		return new ModelAndView("showall","showproduct","myAllProduct");
	}
*/

}
