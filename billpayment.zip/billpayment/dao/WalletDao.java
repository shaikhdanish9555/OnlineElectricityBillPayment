package com.cg.billpayment.dao;
import com.cg.billpayment.dto.*;
import java.math.BigDecimal;

public interface WalletDao {

	public Wallet saveWallet(Wallet  ad);
	public Wallet showTopupbalance();
}
