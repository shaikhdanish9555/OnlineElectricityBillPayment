package com.cg.billpayment.dao;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.billpayment.dto.*;
import com.cg.billpayment.util.DBUtil;

public class WalletDaoImp implements WalletDao{

	/*public Wallet save(Wallet wallet) {
		
		Wallet wall = DBUtil.getwalletData();
		
		String query_insert = "Insert into wallet balance(?)";
		PreparedStatement pstm = null;
		
		try {
			pstm = wall.preparedStatement(query_insert);
			pstm.setBigDecimal(0, null);
			
			pstm.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
		finally {
			try {
				pstm.close();
				
			}
			catch(SQLException e) {
			
			}		
		}
			return null;
			
		}*/
	
	
	
	
	
	
	

	public Wallet saveWallet(Wallet ad) {
		DBUtil.walletData.add(ad);
		return ad;
	}

	public Wallet showTopupbalance() {

		for(Wallet wal:DBUtil.walletData) {
			
			
			
			return wal;
		}
		return null;
		
		
		
	}

}
