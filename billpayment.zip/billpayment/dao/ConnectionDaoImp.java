package com.cg.billpayment.dao;
import com.cg.billpayment.dto.*;
import com.cg.billpayment.util.DBUtil;

import java.util.ArrayList;
import java.util.List;

public class ConnectionDaoImp implements ConnectionDao {
//List<Customer> cust;
	public ConnectionDaoImp()
	{
		//cust=new ArrayList<Customer>();
	}
	
	public Customer save(Customer customer) {
		// TODO Auto-generated method stub
		DBUtil.customerData.add(customer);
		return customer;
	}

	

}
