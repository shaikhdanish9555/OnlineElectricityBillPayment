package com.cg.billpayment.dto;

import java.math.BigInteger;

import java.util.List;

import com.cg.billpayment.dto.Connection;

public class Customer {
	
	private String name;
	private BigInteger contact;
	private List<Connection> connection;
	
	
	
	public Customer()
	{
		
	}
	
	
	public Customer(String name, BigInteger contact, List<Connection> connection) {
		super();
		this.name = name;
		this.contact = contact;
		this.connection = connection;
	}
	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigInteger getContact() {
		return contact;
	}

	public void setContact(BigInteger contact) {
		this.contact = contact;
	}

	public List<Connection> getConnection() {
		return connection;
	}

	public void setConnection(List<Connection> connection) {
		this.connection = connection;
	}


	@Override
	public String toString() {
		return "Customer [name=" + name + ", contact=" + contact + ", connection=" + connection + "]";
	}


}


