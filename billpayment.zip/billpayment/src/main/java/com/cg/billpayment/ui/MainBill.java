package com.cg.billpayment.ui;
import com.cg.billpayment.dto.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.billpayment.dto.Connection;
import com.cg.billpayment.dto.Customer;
import com.cg.billpayment.dto.Transaction;
import com.cg.billpayment.dto.Wallet;
import com.cg.billpayment.service.ConnectionServiceImp;
import com.cg.billpayment.service.TransactionServiceImp;
import com.cg.billpayment.service.WalletServiceImp;
import com.cg.billpayment.util.DBUtil;

public class MainBill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Scanner sc=new Scanner(System.in);
    List<Connection> con=new ArrayList<Connection>();
    
    ConnectionServiceImp imp=new ConnectionServiceImp();
  
    //Consumer_Number; Billing_Unit; Type
    Connection con1=new Connection(new BigInteger("123456789012"),123,null,"Domestic"); 
    Connection con2=new Connection(new BigInteger("123456789013"),222,null,"Commercial"); 
   
    //Adding Individual Connections to the Connection List 
    con.add(con1); 
    con.add(con2); 
     
    //Customer Details (Name, Contact_No., Connection)  
    Customer customer=new Customer("Danish",new BigInteger("8379007172"),con); 
    
     
    DBUtil.connectionData.add(con1);
    DBUtil.connectionData.add(con2);
    
    //Adding the Details of a Customer
    imp.add(customer);
    
    
    System.out.println("......Online Electricity Bill Payment.....");
    System.out.println("*********************************************************************************");
    
    TransactionServiceImp service1=new TransactionServiceImp();
    
    
    Transaction transaction=new Transaction(customer,con, null);
    
    WalletServiceImp ser=new WalletServiceImp();
    
    
    Wallet wall = new Wallet(null,customer,transaction);
   
    int choice=0;
  
  do{
	  System.out.println("1. Add Money To Wallet");
	  System.out.println("2. Show Balance");
	  System.out.println("3. Pay Your Bills");
	  System.out.println("4. Show Last Transaction");
	  choice=sc.nextInt();
	  
	switch(choice) {
	 
	case 1:
		System.out.println("Enter The Balance You Want");
		BigDecimal balance=sc.nextBigDecimal();
		wall.setBalance(balance);
		ser.addMoney(wall);
	    
		break;
	case 2:
	
	Wallet wallone=ser.showBalance();
	System.out.println(wallone.getBalance());
	break;
	case 3:
		int choice1=0;
		 BigDecimal amount;
			Wallet walltwo=ser.showBalance(); 
		 System.out.println("Please Enter The Type of Bill You Want To Pay \n 1. Domestic \n 2. Commercial");
		 choice1=sc.nextInt();
		 switch(choice1)
		 {
		
		 case 1:
			 System.out.println("Enter The Amount");
			 amount=sc.nextBigDecimal();
			 
			 con1.setAmount(amount);
		 
		    		
				int res=walltwo.getBalance().compareTo(amount);
		    	
		    	if(res==1) {
		    		
		    		wall.setBalance(walltwo.getBalance().subtract(amount));
	    		    transaction.setAmount(amount);
	    		    System.out.println("Your Bill Has been Paid Successfully...");
		    		System.out.println("After Paying The Bill, Now Your Wallet Balance is:");
	    		    System.out.println(walltwo.getBalance());		
	    		    System.out.println("Please Proceed Further... ");
				}
		    	else
		    	{
		    		System.out.println("SORRY!!! Not Sufficient Balance To Pay The Bill....!");
		    	}
		    	break;
		 case 2: 
			 System.out.println("Enter the amount");
			 amount=sc.nextBigDecimal();
			 con2.setAmount(amount);
			 
		
				int res2=walltwo.getBalance().compareTo(amount);
		    	
		    	if(res2==1) {
		    	
		    		wall.setBalance(walltwo.getBalance().subtract(amount));
	    		    transaction.setAmount(amount);
		    		System.out.println(walltwo.getBalance());					
				}
		    	else
		    	{
		    		System.out.println("SORRY!!! No Sufficient Balance To Pay The Bill....!");
		    	}
		 }	
		    	
		 break;
		
	case 4:
		  System.out.println("Transaction Details are: ");
		
		  System.out.println(customer.getName()+"  "+customer.getContact()+"  ");
		  System.out.println("Domestic "+ con1.getBillingUnit() +" "+con1.getAmount());
		  System.out.println("commercial "+ con2.getBillingUnit() +" "+con2.getAmount());
		
		
		    	}
			 	 
  }while(choice!=5);
	}
}
   
    