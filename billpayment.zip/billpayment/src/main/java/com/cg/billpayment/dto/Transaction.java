package com.cg.billpayment.dto;

import java.math.BigDecimal;
import java.util.List;

import com.cg.billpayment.dto.Connection;
import com.cg.billpayment.dto.Customer;

public class Transaction {
	
	private Customer customer;
	private List<Connection> connection;
	private BigDecimal amount;
	
	
	public Transaction()
	{
		
	}


	public Transaction(Customer customer, List<Connection> connection, BigDecimal amount) {
		super();
		this.customer = customer;
		this.connection = connection;
		this.amount = amount;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public List<Connection> getConnection() {
		return connection;
	}


	public void setConnection(List<Connection> connection) {
		this.connection = connection;
	}


	public BigDecimal getAmount() {
		return amount;
	}


	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}


	@Override
	public String toString() {
		return "Transaction [customer=" + customer + ", connection=" + connection + ", amount=" + amount + "]";
	}
	
	
}


