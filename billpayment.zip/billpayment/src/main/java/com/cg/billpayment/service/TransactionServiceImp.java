package com.cg.billpayment.service;

import com.cg.billpayment.dao.TransactionDaoImp;
import com.cg.billpayment.dto.*;
import java.math.BigDecimal;
import java.math.BigInteger;

    public class TransactionServiceImp implements TransactionService{

     	TransactionDaoImp dao=new TransactionDaoImp();
    	
   
		public Transaction lastTransaction(Transaction consumerNumber) {
			// TODO Auto-generated method stub
			return dao.lastTransactionOne(consumerNumber) ;
		}


    	
    	
    	
    	
    	
    	
    	
    	
    /*TransactionDaoImp dao=new TransactionDaoImp();
	
	@Override
	public Transaction lastTransaction(Transaction consumerNumber) {
		// TODO Auto-generated method stub
		return dao.lastTransactionOne(consumerNumber);
	}
*/
	

}
