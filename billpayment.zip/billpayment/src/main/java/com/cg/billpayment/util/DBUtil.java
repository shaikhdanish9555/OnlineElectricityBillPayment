package com.cg.billpayment.util;
import com.cg.billpayment.dto.*;
import java.util.ArrayList;
import java.util.List;

public class DBUtil 
{

	
	public static List<Transaction> transactionData = new ArrayList<Transaction>();
	public static List<Customer> customerData = new ArrayList<Customer>();
	public static List<Wallet> walletData = new ArrayList<Wallet>();
	public static List<Connection> connectionData = new ArrayList<Connection>();
	
}
