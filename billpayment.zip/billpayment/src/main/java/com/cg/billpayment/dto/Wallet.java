package com.cg.billpayment.dto;

import java.math.BigDecimal;

import com.cg.billpayment.dto.Customer;

import com.cg.billpayment.dto.Transaction;

public class Wallet {

	private BigDecimal balance;
	private Customer customer;
	private Transaction transaction;
	

	public Wallet()
	{
				
	}
	

	public Wallet(BigDecimal balance, Customer customer) {
		super();
		this.balance = balance;
		this.customer = customer;
	}


	public Wallet(BigDecimal balance, Customer customer, Transaction transaction) {
		super();
		this.balance = balance;
		this.customer = customer;
		this.transaction = transaction;
	}


	public BigDecimal getBalance() {
		return balance;
	}


	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public Transaction getTransaction() {
		return transaction;
	}


	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}


	@Override
	public String toString() {
		return "Wallet [balance=" + balance + ", customer=" + customer + ", transaction=" + transaction + "]";
	}
			

}

