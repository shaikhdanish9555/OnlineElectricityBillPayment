package com.cg.billpayment.dao;
import java.sql.DriverManager;
import java.math.BigDecimal;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.billpayment.dto.*;
import com.cg.billpayment.exceptions.ConnectionException;
import com.cg.billpayment.exceptions.ConnectionNotEstablishedException;
import com.cg.billpayment.exceptions.WalletException;
import com.cg.billpayment.util.DBUtil;

public class WalletDaoImp implements WalletDao{
	 
	EntityManager em=null;
	public WalletDaoImp()
	{
		em=DBUtil.getConnection();
	}

	public Wallet saveWallet(Wallet ad) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		try {
				
				em.getTransaction().begin();
				em.persist(ad);
				em.getTransaction().commit();
				
				
		}
		catch(IllegalStateException e1)
		{
			System.out.println("add the customer first");
			
		}
				 
		return null;
	}

	public Wallet showTopupbalance(int id) throws WalletException {
		 
		//Starting the Transaction Service 
		em.getTransaction().begin();	    
		 
		 Wallet wallet= em.find(Wallet.class, id);
		 
		//Ending the Transaction Service
		 em.getTransaction().commit();
		 
		
		return wallet;
		
	 
	}

}
	


