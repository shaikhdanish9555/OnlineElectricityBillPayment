package com.cg.billpayment.dto;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.cg.billpayment.dto.Connection;
import com.cg.billpayment.dto.Customer;
import com.cg.billpayment.util.DBUtil;

@Entity
public class Transaction {
	
	@Id
    private int id; 
	
	private BigDecimal amount;
	 @OneToMany
    @JoinColumn(name="trans_id")
	private List<com.cg.billpayment.dto.Connection> connection;
	public List<Connection> getConnection() {
		return connection;
	}


	public void setConnection(List<Connection> connection) {
		this.connection = connection;
	}


	public Transaction()
	{
		
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public BigDecimal getAmount() {
		return amount;
	}


	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	



}


