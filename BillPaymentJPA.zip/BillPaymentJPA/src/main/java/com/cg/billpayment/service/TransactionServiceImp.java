package com.cg.billpayment.service;

import com.cg.billpayment.dao.TransactionDaoImp;
import com.cg.billpayment.dto.*;
import java.math.BigDecimal;
import java.math.BigInteger;

    public class TransactionServiceImp implements TransactionService{
    	TransactionDaoImp dao=null;
             public TransactionServiceImp() {
				// TODO Auto-generated constructor stub
			
     	   dao=new TransactionDaoImp();
             }
    	
    	// Last Transaction's method
		public Transaction lastTransaction(Wallet transaction) {
			
			return dao.lastTransactionOne(transaction) ;
		}
		
		// Getting Mobile Number in Last Transaction
		public Transaction getTransaction(BigInteger mobileNo)
		{
			
			return dao.getTransaction(mobileNo);
			
			
		}

    	
    	
    	
    	
    	
    	
    	
    	
   
	

}
