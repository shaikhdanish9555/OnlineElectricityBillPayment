package com.cg.billpayment.ui;
import com.cg.billpayment.dto.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.billpayment.dto.Connection;
import com.cg.billpayment.dto.Customer;
import com.cg.billpayment.dto.Transaction;
import com.cg.billpayment.dto.Wallet;
import com.cg.billpayment.exceptions.WalletException;
import com.cg.billpayment.service.ConnectionServiceImp;
import com.cg.billpayment.service.TransactionServiceImp;
import com.cg.billpayment.service.WalletServiceImp;
import com.cg.billpayment.util.DBUtil;

public class MainBill {

	public static void main(String[] args) {

		
	Scanner sc=new Scanner(System.in);
    ConnectionServiceImp cservice = new ConnectionServiceImp();
    
    // Object Creation Of List of Connections
	List<Connection> conlist=new ArrayList<Connection>();
    
    // Object Creation Of Connection taken "imp" as a variable for adding Connection data
	 
  
    // Consumer_Number; Billing_Unit; Type
     
    // Adding Individual Connections to the Connection List 
   
     
    // Customer Details (Name, Contact_No., Connection)  
   
    
     
   // DBUtil.connectionData.add(con1);
   // DBUtil.connectionData.add(con2);
    
    // Adding the Details of a Customer
  
    
    System.out.println("......Online Electricity Bill Payment.....");
    System.out.println("*********************************************************************************");
    
    // Object Creation Of Transaction Service
    TransactionServiceImp service1=new TransactionServiceImp();
    
    // Object Creation Of Transaction POJO
   
    
    // Object Creation Of Wallet Service
    WalletServiceImp ser=new WalletServiceImp();
    
    // Object Creation Of Wallet POJO
    Wallet wall = new Wallet();
	Customer customerone=new Customer();
   
    int choice=0;
  
  do{
	  System.out.println("1. Add The Customers");
	  System.out.println("2. Add Money To Wallet");
	  System.out.println("3. Show Balance");
	  System.out.println("4. Pay Your Bills");
	  System.out.println("5. Show Last Transaction");
	  choice=sc.nextInt();
  
	switch(choice) 
	{
	
	case 1:

		 
		
		
		System.out.println("Enter The Customer Name");
		String name = sc.next();
		System.out.println("Enter The Customer Contact Number");
		String number = sc.next();
		
		String choice2="yes";
		do {
			Connection con=new Connection();
			System.out.println("Enter the Type of Connection");
			String type = sc.next();
		System.out.println("Enter Consumer Number");
		BigInteger consumerno=sc.nextBigInteger();
		System.out.println("Enter The Billing Unit");
		int unit=sc.nextInt();
		System.out.println("Enter The Amount");
		BigDecimal amount1=sc.nextBigDecimal();
		
		con.setConsumerNumber(consumerno);
		con.setAmount(amount1);
		con.setBillingUnit(unit);
		con.setType(type);
		conlist.add(con);
		System.out.println("Do U want add more Connections Yes or No");
		choice2=sc.next();
		
		}
		while(choice2.equals("yes"));
		
		customerone.setName(name);
		customerone.setContact(number);
		customerone.setConnection(conlist);
		
		cservice.add(customerone);
		System.out.println("Customers Added Successfully");
		break;
		
	 	
		case 2:
			System.out.println("Enter wallet id");
			int id=sc.nextInt();
		    System.out.println("Enter The Balance ");
		    BigDecimal balance=sc.nextBigDecimal();
		  
		   
		   
			wall.setId(id); 
			wall.setBalance(balance);
			wall.setCustomer(customerone);
			ser.addMoney(wall);
		    System.out.println("Money is Succesfully Added");
  
		    break;
		
  
	case 3:
		
		// Show Balance Method is called
		
				
				try {
					System.out.println("enter your  wallet id");
					int wallid=sc.nextInt();
					 System.out.println("YOUR CURRENT WALLET BALANCE IS  " +ser.showBalance(wallid).getBalance());
					
				} catch (WalletException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			
			break;
			
	case 4:
		     Wallet wallet1=new Wallet();
		      List<Transaction> listtransaction=new ArrayList<Transaction>();
		      Transaction transaction=new Transaction();
				int choice1=0;
				 BigDecimal amount;
				 
				 // Show Balance Method is called again before the bill payment
				 
		      System.out.println("Please Enter The Type of Bill You Want To Pay \n 1. Domestic \n 2. Commercial");
				 choice1=sc.nextInt();
				 switch(choice1)
				 {
				
				 case 1:
					 System.out.println("enter wallet id");
					 int id1=sc.nextInt();
					 wallet1.setId(id1);
					 System.out.println("Enter The Amount");
					 amount=sc.nextBigDecimal();
		             System.out.println("enter trans id");
		             int transid=sc.nextInt();
					 transaction.setAmount(amount);
					
					 
				 
				    		
						int res=wall.getBalance().compareTo(amount);
				    	
				    	if(res==1) {
				    		
				    		
				    		wall.setBalance(wall.getBalance().subtract(amount));
			    		    transaction.setAmount(amount);
			    		    transaction.setId(transid);
			    		    transaction.setConnection(conlist);
			    		    wall.setCustomer(customerone);
			    		    listtransaction.add(transaction);
			    		    wall.setTransaction(listtransaction);
			    		    service1.lastTransaction(wallet1);
			    		    
			    		    System.out.println("Your Bill Has been Paid Successfully...");
				    		System.out.println("After Paying The Bill, Now Your Wallet Balance is:");
			    		    System.out.println();		
			    		    System.out.println("Please Proceed Further... ");
						}
				    	else
				    	{
				    		System.out.println("SORRY!!! Not Sufficient Balance To Pay The Bill....!");
				    	}
				    	break;
				/* case 2: 
					 System.out.println("Enter the amount");
					 amount=sc.nextBigDecimal();
					 con2.setAmount(amount);
					 
				
						int res2=walltwo.getBalance().compareTo(amount);
				    	
				    	if(res2==1) {
				    	
				    		wall.setBalance(walltwo.getBalance().subtract(amount));
			    		    transaction.setAmount(amount);
			    		
			    		    service1.lastTransaction(transaction);
			    		    
				    		System.out.println(walltwo.getBalance());					
						}
				    else
				    	{
				    		System.out.println("SORRY!!! No Sufficient Balance To Pay The Bill....!");
				    	}
				    break;
			*/
case 5:
		

	  System.out.println("Transaction Details are: ");
	  System.out.println("Enter The MobileNumber");
	  BigInteger mobile=sc.nextBigInteger();
	  Transaction trans= service1.getTransaction(mobile);
	  System.out.println(trans);
				 }
				 
	}				 		 
  }while(choice!=5);
  
	}
}
	
  
	
  


   
    