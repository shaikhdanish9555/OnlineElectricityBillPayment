package com.cg.billpayment.dto;


import java.math.BigDecimal;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Connection {
	
	 @Id
	private BigInteger consumerNumber;
	 
	private int billingUnit;
	 
	BigDecimal amount;
	 
	private String type; 

	
	public Connection()
	{
		
	}

	
	

  public BigInteger getConsumerNumber() {
		return consumerNumber;
	}

  public void setConsumerNumber(BigInteger consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

  public int getBillingUnit() {
		return billingUnit;
	}

   public void setBillingUnit(int billingUnit) {
		this.billingUnit = billingUnit;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Connection [consumerNumber=" + consumerNumber + ", billingUnit=" + billingUnit + ", amount=" + amount
				+ ", type=" + type + "]";
	}


	public void add(Customer customer) {
		// TODO Auto-generated method stub
		
	}


	public Customer save(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}


	

		
}



