package com.cg.billpayment.service;

import com.cg.billpayment.dto.*;
import java.math.BigDecimal;
import java.math.BigInteger;

import com.cg.billpayment.dto.Transaction;

public interface TransactionService {
	
	// Last Transaction method
	public Transaction lastTransaction(Wallet transaction);
	
	// Getting Mobile Number in Last Transaction
	public Transaction getTransaction(BigInteger mobileNo);
}
