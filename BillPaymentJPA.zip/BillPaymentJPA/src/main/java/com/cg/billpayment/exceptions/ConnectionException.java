package com.cg.billpayment.exceptions;

public class ConnectionException extends Exception {

	public ConnectionException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
