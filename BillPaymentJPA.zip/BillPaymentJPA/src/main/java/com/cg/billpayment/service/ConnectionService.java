package com.cg.billpayment.service;

import com.cg.billpayment.dto.Customer;

public interface ConnectionService {


	public Customer add(Customer customer);
}
