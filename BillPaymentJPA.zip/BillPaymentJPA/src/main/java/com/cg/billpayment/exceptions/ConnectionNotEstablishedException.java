package com.cg.billpayment.exceptions;

public class ConnectionNotEstablishedException extends Exception {

	public ConnectionNotEstablishedException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
