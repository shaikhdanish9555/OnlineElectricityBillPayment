package com.cg.billpayment.service;

import java.math.BigDecimal;

import com.cg.billpayment.dto.Wallet;
import com.cg.billpayment.exceptions.ConnectionException;
import com.cg.billpayment.exceptions.WalletException;

public interface WalletService {
	
	
	// Method for Adding the Money into the Wallet
	public Wallet addMoney(Wallet ad);
	
	// Method for Showing the Balance of the Wallet
	public Wallet showBalance(int id) throws WalletException;
}
