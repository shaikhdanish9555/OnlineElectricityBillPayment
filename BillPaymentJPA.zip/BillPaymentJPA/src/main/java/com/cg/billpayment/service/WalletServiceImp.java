package com.cg.billpayment.service;

import com.cg.billpayment.dao.WalletDaoImp;
import com.cg.billpayment.dto.*;
import com.cg.billpayment.exceptions.ConnectionException;
import com.cg.billpayment.exceptions.WalletException;

import java.math.BigDecimal;


public class WalletServiceImp implements WalletService{

	
	WalletDaoImp da;
	
	public WalletServiceImp() {
		
		da=new WalletDaoImp();
	}

	// Method for Adding the Money into the Wallet
	public Wallet addMoney(Wallet ad) {
	try {
		
		{
			return da.saveWallet(ad);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return ad;
	}
	
	// Method for Showing the Balance of the Wallet
	public Wallet showBalance(int id) throws WalletException {
					
		try {
			return da.showTopupbalance(id);
		} catch (Exception e) {

			e.printStackTrace();
		}
		return null;
	}

}
