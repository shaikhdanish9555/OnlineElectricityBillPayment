package com.cg.billpayment.dto;

import java.math.BigInteger;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.cg.billpayment.dto.Connection;

@Entity
public class Customer {
	
	 
	private String name;
	@Id 
	private String contact;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="contact")
	private List<Connection> connection;
	
	
	
	public Customer()
	{
		
	}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public List<Connection> getConnection() {
		return connection;
	}

	public void setConnection(List<Connection> connection) {
		this.connection = connection;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", contact=" + contact + ", connection=" + connection + "]";
	}
	
	


}


