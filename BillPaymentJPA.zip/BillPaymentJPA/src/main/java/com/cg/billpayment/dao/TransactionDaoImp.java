package com.cg.billpayment.dao;
import com.cg.billpayment.dto.*;
import java.sql.*;
import java.sql.Connection;

import com.cg.billpayment.util.DBUtil;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

public class TransactionDaoImp implements TransactionDao  {
	
	EntityManager em=null;
	public TransactionDaoImp()
	{
		em=DBUtil.getConnection();
	}
	

	public Transaction lastTransactionOne(Wallet transaction) {
		 
		   List<Transaction> mylist= transaction.getTransaction();
		   for(Transaction obj:mylist)
		   {
		Query query=em.createNativeQuery("insert into transaction values(?,?,?)");
		query.setParameter(1, obj.getId());
		query.setParameter(2, obj.getAmount());
		query.setParameter(3, transaction.getId());
		query.executeUpdate();
		
		   }
		
		return null;
	 
	}

	public Transaction getTransaction(BigInteger mobileNo) {
		// TODO Auto-generated method stub
		return null;
	}
}
	 