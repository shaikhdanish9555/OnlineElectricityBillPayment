package com.cg.billpayment.dao;
import com.cg.billpayment.dto.*;
import com.cg.billpayment.exceptions.ConnectionException;
import com.cg.billpayment.exceptions.WalletException;

import java.math.BigDecimal;

public interface WalletDao {

	public Wallet saveWallet(Wallet  ad);
	public Wallet showTopupbalance(int id) throws WalletException;
}
