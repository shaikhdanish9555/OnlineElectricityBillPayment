package com.cg.billpayment.service;

import com.cg.billpayment.dao.ConnectionDaoImp;
import com.cg.billpayment.dto.Connection;
import com.cg.billpayment.dto.Customer;

public class ConnectionServiceImp implements ConnectionService {

	
	 ConnectionDaoImp dao;
	    
	    public ConnectionServiceImp()
	    {
	    	dao=new ConnectionDaoImp();
	    }
		
	
	
	
	public Customer add(Customer customer) {
		// TODO Auto-generated method stub
		return dao.save(customer);
	
	
	}
}
	

/*    ConnectionDaoImp dao;
    
    public ConnectionServiceImp()
    {
    	dao=new ConnectionDaoImp();
    }
	

	public Customer add(Customer customer) {
		// TODO Auto-generated method stub
	
		return dao.save(customer);
	}
*/
	


