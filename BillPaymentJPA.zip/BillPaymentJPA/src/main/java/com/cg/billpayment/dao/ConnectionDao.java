package com.cg.billpayment.dao;

import com.cg.billpayment.dto.Customer;

public interface ConnectionDao {
	public Customer save(Customer customer);

}
