package com.cg.billpayment.dto;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.cg.billpayment.dto.Customer;

import com.cg.billpayment.dto.Transaction;
@Entity
public class Wallet {
	@Id
    int id;
 
	private BigDecimal balance;
	@OneToOne
	@JoinColumn(name="contact")
	private Customer customer;
	@OneToMany
	
	@JoinColumn(name="wallet_id")
	private List<Transaction> transaction;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<Transaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() {
		return "Wallet [id=" + id + ", balance=" + balance + ", customer=" + customer + ", transaction=" + transaction
				+ "]";
	}
	

	
}

