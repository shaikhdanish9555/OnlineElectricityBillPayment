package com.cg.billpayment.dao;
import com.cg.billpayment.dto.*;

import java.math.BigDecimal;
import java.math.BigInteger;

public interface TransactionDao {
	
	
	// Last Transaction's method
	public Transaction lastTransactionOne(Wallet transaction);
	
	// Getting Mobile Number in Last Transaction
	public Transaction getTransaction(BigInteger mobileNo);
}
