package com.cg.billpayment.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.billpayment.dto.Customer;
import com.cg.billpayment.util.DBUtil;

public class ConnectionDaoImp implements ConnectionDao{
       EntityManager em=null;
	//Saving the Customers those are Added
	  public ConnectionDaoImp()
	  {
		  em=DBUtil.getConnection();
	  }
	
	
	public Customer save(Customer customer) {
		// TODO Auto-generated method stub
		 
		//Starting the Transaction Service
		em.getTransaction().begin();
		
		//Saving the Customer Info
		em.persist(customer);
		
		//Ending the Transaction Service
		em.getTransaction().commit();
		
		//Closing the Connection for Entity Manager
		 
		//Closing the Connection for Entity Manager Factory
		 
		return customer;
	}

}
