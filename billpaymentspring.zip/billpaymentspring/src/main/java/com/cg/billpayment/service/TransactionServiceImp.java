package com.cg.billpayment.service;

import com.cg.billpayment.dao.TransactionDaoImp;
import com.cg.billpayment.dto.*;
import java.math.BigDecimal;
import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("transactionservice")
    public class TransactionServiceImp implements TransactionService{
@Autowired
     	TransactionDaoImp dao;
    	
   
		public Transaction lastTransaction(Transaction consumerNumber) {
			// TODO Auto-generated method stub
			return dao.lastTransactionOne(consumerNumber) ;
		}

		public Transaction getTransaction()
		{
			return dao.getTransaction();
			
		}
    	
    	
    	
    	
    	
    	
    	
  
	

}
