package com.cg.billpayment.service;

import com.cg.billpayment.dao.WalletDaoImp;
import com.cg.billpayment.dto.*;
import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("walletservice")
public class WalletServiceImp implements WalletService{

	
	
	@Autowired
	WalletDaoImp da;
	
	public WalletServiceImp() {
		
		da=new WalletDaoImp();
	}

	
	public Wallet addMoney(Wallet ad) {
		// TODO Auto-generated method stub
		return da.saveWallet(ad);
	}


	public Wallet showBalance() {
		// TODO Auto-generated method stub
		return da.showTopupbalance();
	}

	
	
}
