package com.cg.billpayment.ui;
import com.cg.billpayment.config.JavaConfig;
import com.cg.billpayment.dto.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.billpayment.dto.Connection;
import com.cg.billpayment.dto.Customer;
import com.cg.billpayment.dto.Transaction;
import com.cg.billpayment.dto.Wallet;
import com.cg.billpayment.exceptions.WalletException;
import com.cg.billpayment.service.ConnectionService;
import com.cg.billpayment.service.ConnectionServiceImp;
import com.cg.billpayment.service.TransactionService;
import com.cg.billpayment.service.TransactionServiceImp;
import com.cg.billpayment.service.WalletService;
import com.cg.billpayment.service.WalletServiceImp;
import com.cg.billpayment.util.DBUtil;
@Component
public class MainBill {
	@Autowired
	ConnectionService cservice ;
	@Autowired
	WalletService wservice;
	@Autowired
	TransactionService tservice1;
	static WalletService walletservice;
	static ConnectionService connService;
	static TransactionService tservice;
	@PostConstruct
	public void init()
	{
		connService  =this.cservice;
		walletservice=this.wservice;
		this.tservice=tservice1;
		
	}
	public static void main(String[] args) {

		ApplicationContext app=new AnnotationConfigApplicationContext(JavaConfig.class);
	Scanner sc=new Scanner(System.in);
    
	Customer cust = null;
    // Object Creation Of List of Connections
	List<Connection> conlist=new ArrayList<Connection>();
    
    // Object Creation Of Connection taken "imp" as a variable for adding Connection data
	 
  
    // Consumer_Number; Billing_Unit; Type
     
    // Adding Individual Connections to the Connection List 
   
     
    // Customer Details (Name, Contact_No., Connection)  
   
    
     
   // DBUtil.connectionData.add(con1);
   // DBUtil.connectionData.add(con2);
    
    // Adding the Details of a Customer
  
    
    System.out.println("......Online Electricity Bill Payment.....");
    System.out.println("*********************************************************************************");
    
    
    
    // Object Creation Of Transaction POJO
   
    
    // Object Creation Of Wallet Service
 
    
  
 
   
    int choice=0;
  
  do{
	  System.out.println("1. Add The Customers");
	  System.out.println("2. Add Money To Wallet");
	  System.out.println("3. Show Balance");
	  System.out.println("4. Pay Your Bills");
	  System.out.println("5. Show Last Transaction");
	  choice=sc.nextInt();
  
	switch(choice) 
	{
	
	case 1:

		 
		
		
		System.out.println("Enter The Customer Name");
		String name = sc.next();
		System.out.println("Enter The Customer Contact Number");
		String number = sc.next();
		
		String choice2="yes";
		do {
			
			System.out.println("Enter the Type of Connection");
			String type = sc.next();
		System.out.println("Enter Consumer Number");
		BigInteger consumerno=sc.nextBigInteger();
		System.out.println("Enter The Billing Unit");
		int unit=sc.nextInt();
		System.out.println("Enter The Amount");
		BigDecimal amount1=sc.nextBigDecimal();
		Connection con=(Connection) app.getBean("connection");
	
		con.setConsumerNumber(consumerno);
		con.setAmount(amount1);
		con.setBillingUnit(unit);
		con.setType(type);
		conlist.add(con);
		System.out.println("Do U want add more Connections Yes or No");
	  	    choice2=sc.next();
		
		
		}
		while(choice2.equals("yes"));
		
	

		 
	
		//customerone.setContact(number);
		//customerone.setConnection(conlist);
		 cust=app.getBean(Customer.class);
		cust.setName(name);
		cust.setContact(new BigInteger(number));
		cust.setConnection(conlist);
		connService.add(cust);
		System.out.println("Customers Added Successfully");
		break;
		
	 	
		case 2:
			Wallet wall=app.getBean(Wallet.class);
			System.out.println("Enter wallet id");
			int id=sc.nextInt();
		    System.out.println("Enter The Balance ");
		    BigDecimal balance=sc.nextBigDecimal();
		  
		   
		   
			//wall.setId(id); 
			wall.setBalance(balance);
			wall.setCustomer(cust);
			walletservice.addMoney(wall);
		    System.out.println("Money is Succesfully Added");
  
		    break;
		
  
	case 3:
		
		// Show Balance Method is called
		
			
		System.out.println("enter your  wallet id");
		int wallid=sc.nextInt();
		 System.out.println("YOUR CURRENT WALLET BALANCE IS  " +walletservice.showBalance().getBalance());
			
			break;
			
	case 4:
		int choice1=0;
		 BigDecimal amount;
			Wallet walltwo=walletservice.showBalance(); 
			Transaction tra1=new  Transaction();
			Wallet wall1=new Wallet();
		 System.out.println("Please Enter The Type of Bill You Want To Pay \n 1. Domestic \n 2. Commercial");
		 choice1=sc.nextInt();
		 switch(choice1)
		 {
		
		 case 1:
			 System.out.println("Enter The Amount");
			 amount=sc.nextBigDecimal();
			 
			// con1.setAmount(amount);
		 
		    		
				int res=walltwo.getBalance().compareTo(amount);
		    	
		    	if(res==1) {
		    		
		    		wall1.setBalance(walltwo.getBalance().subtract(amount));
	    		    tra1.setAmount(amount);
	    		    System.out.println("Your Bill Has been Paid Successfully...");
		    		System.out.println("After Paying The Bill, Now Your Wallet Balance is:");
	    		   // System.out.println(walltwo.getBalance());		
	    		    System.out.println("Please Proceed Further... ");
	    		    tra1.setCustomer(cust);
	    		    tservice.lastTransaction(tra1);
				}
		    	else
		    	{
		    		System.out.println("SORRY!!! Not Sufficient Balance To Pay The Bill....!");
		    	}
		    	break;
		 case 2: 
			 System.out.println("Enter the amount");
			 amount=sc.nextBigDecimal();
			 //con2.setAmount(amount);
			 
		
				int res2=walltwo.getBalance().compareTo(amount);
		    	
		    	if(res2==1) {
		    	
		    		wall1.setBalance(walltwo.getBalance().subtract(amount));
		    		tra1.setCustomer(cust);
	    		    tra1.setAmount(amount);
		    		//System.out.println(walltwo.getBalance());
	    		    tservice.lastTransaction(tra1);
				}
		    	else
		    	{
		    		System.out.println("SORRY!!! No Sufficient Balance To Pay The Bill....!");
		    	}
		 }	
		    	
		 break;
case 5:
		

	  System.out.println("Transaction Details are: ");
	 System.out.println( tservice.getTransaction());
				 
				 
	}				 		 
  }
	
	
	
	
	while(choice!=5);
  
	}
}
	
  
	
  


   
    