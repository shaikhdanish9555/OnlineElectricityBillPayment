package com.cg.billpayment.service;

import com.cg.billpayment.dto.*;
import java.math.BigDecimal;
import java.math.BigInteger;

import com.cg.billpayment.dto.Transaction;

public interface TransactionService {
	
	public Transaction lastTransaction(Transaction consumerNumber);
	public Transaction getTransaction();
}
