package com.cg.billpayment.exceptions;

public class WalletException extends Exception {

}
