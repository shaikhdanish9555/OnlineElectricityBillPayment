package com.cg.billpayment.service;

import java.math.BigDecimal;

import com.cg.billpayment.dto.Wallet;

public interface WalletService {
	
	public Wallet addMoney(Wallet ad);
	
	public Wallet showBalance();
}
