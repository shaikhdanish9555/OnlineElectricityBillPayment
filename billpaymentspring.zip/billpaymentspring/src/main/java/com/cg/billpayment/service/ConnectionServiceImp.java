package com.cg.billpayment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billpayment.dao.ConnectionDao;
import com.cg.billpayment.dao.ConnectionDaoImp;
import com.cg.billpayment.dto.Customer;
@Component("connService")
public class ConnectionServiceImp implements ConnectionService {

	@Autowired
	 ConnectionDaoImp dao;
	    
	    public ConnectionServiceImp()
	    {
	    	 
	    }
		
	
	
	
	public Customer add(Customer customer) {
		// TODO Auto-generated method stub
		return dao.save(customer);
	}
	
	
	
	

/*    ConnectionDaoImp dao;
    
    public ConnectionServiceImp()
    {
    	dao=new ConnectionDaoImp();
    }
	

	public Customer add(Customer customer) {
		// TODO Auto-generated method stub
	
		return dao.save(customer);
	}
*/
	

}
