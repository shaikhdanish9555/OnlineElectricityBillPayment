package com.cg.billpayment.dao;
import com.cg.billpayment.dto.*;
import java.math.BigInteger;

public interface TransactionDao {

	public Transaction lastTransactionOne(Transaction consumerNumber);
}
