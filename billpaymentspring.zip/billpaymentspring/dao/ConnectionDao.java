package com.cg.billpayment.dao;
import com.cg.billpayment.dto.*;

public interface ConnectionDao {
	
	public Customer save(Customer customer);
}
