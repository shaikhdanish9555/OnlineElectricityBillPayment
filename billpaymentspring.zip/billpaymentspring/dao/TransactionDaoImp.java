package com.cg.billpayment.dao;
import com.cg.billpayment.dto.*;
import com.cg.billpayment.util.DBUtil;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class TransactionDaoImp implements TransactionDao  {

	public Transaction lastTransactionOne(Transaction consumerNumber) {
		
		DBUtil.transactionData.add(consumerNumber);
		return consumerNumber;
	}


}
