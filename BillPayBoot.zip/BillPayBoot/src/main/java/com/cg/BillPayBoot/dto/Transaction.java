package com.cg.BillPayBoot.dto;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.cg.BillPayBoot.dto.Connection;
import com.cg.BillPayBoot.dto.Customer;


/*
 * 
 Transaction DTO Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

@Entity
@Table(name="transaction")
public class Transaction {
	
	
	@Id
	@Column(name="transaction_id")
    private int id; 
	@Column(name="transaction_amount")
	private BigDecimal amount;
	@OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="Connection_id")
	private Connection connection;
	//private List<com.cg.billpaymentmvc.dto.Connection> connection;
		

	
	public Transaction() {
		
	}

public Transaction(int id, BigDecimal amount, Connection connection) {
	super();
	this.id = id;
	this.amount = amount;
	this.connection = connection;
}



public int getId() {
	return id;
}



public void setId(int id) {
	this.id = id;
}



public BigDecimal getAmount() {
	return amount;
}



public void setAmount(BigDecimal amount) {
	this.amount = amount;
}



public Connection getConnection() {
	return connection;
}



public void setConnection(Connection connection) {
	this.connection = connection;
}



@Override
public String toString() {
	return "Transaction [id=" + id + ", amount=" + amount + ", connection=" + connection + "]";
}


}

