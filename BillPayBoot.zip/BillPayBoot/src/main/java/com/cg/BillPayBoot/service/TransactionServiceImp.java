package com.cg.BillPayBoot.service;

import com.cg.BillPayBoot.dao.TransactionDao;
import com.cg.BillPayBoot.dao.WalletDao;
import com.cg.BillPayBoot.dto.*;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


/*
 * 
 Transaction Service Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */


@Service
@Transactional
public class TransactionServiceImp implements TransactionService{

@Autowired
WalletDao dao;



@Override
public Transaction getTransaction() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public Transaction lastTransaction(Wallet consumerNumber) {
	// TODO Auto-generated method stub
	dao.save(consumerNumber);
	return null;
}
    	
/*
 * 
 Transaction Service Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

	

	
    	
}
		
		
		
		//Get the Details of the Last Transaction and throws an Exception
		/*
		 * 
		 Transaction Service Class implemented by 
		 @Author: Danish Shaikh
		 @Version:1.0
		 @Since: 11-05-2019
		 */
		
			/*if(obj==null)
			{
				throw new WalletException(" Transaction Does Not Exist....!!!!");
			}
			else
			{
				return obj;
			}*/

