package com.cg.BillPayBoot.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cg.BillPayBoot.dto.*;


/*
 * 
 Connection Dao Interface Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */
@EnableJpaRepositories

public interface ConnectionDao extends JpaRepository<Customer, Integer>{

	//void save(Customer customer);
	
	
}


