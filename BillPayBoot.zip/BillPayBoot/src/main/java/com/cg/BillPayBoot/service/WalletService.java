package com.cg.BillPayBoot.service;

import java.math.BigDecimal;

import com.cg.BillPayBoot.dto.Wallet;

/*
 * 
 Wallet Service Interface Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */


public interface WalletService {
	
	public Wallet addMoney(Wallet ad);
	
	public Wallet showBalance(int id);
}
