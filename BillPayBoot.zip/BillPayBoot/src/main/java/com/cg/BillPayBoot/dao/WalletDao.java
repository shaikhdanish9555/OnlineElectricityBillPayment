package com.cg.BillPayBoot.dao;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.BillPayBoot.dto.*;

/*
 * 
 Wallet Dao Interface Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */


public interface WalletDao extends JpaRepository<Wallet, Integer>{
 
	public Wallet findByid(int id);

	
	
}


