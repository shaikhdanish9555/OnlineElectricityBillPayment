package com.cg.BillPayBoot.service;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.cg.BillPayBoot.dto.*;

/*
 * 
 Transaction Service Interface Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */


public interface TransactionService {
	
	public Transaction lastTransaction(Wallet consumerNumber);
	public Transaction getTransaction(); /*throws WalletException*/
}
