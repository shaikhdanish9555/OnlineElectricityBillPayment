package com.cg.BillPayBoot.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.BillPayBoot.dao.ConnectionDao;
import com.cg.BillPayBoot.dto.Customer;


/*
 * 
 Connection Service Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

@Service
@Transactional
public class ConnectionServiceImp implements ConnectionService {

@Autowired
ConnectionDao dao;
	    
	    public ConnectionServiceImp()
	    {
	    	 
	    }
	   
	    public Customer add(Customer customer) {
			// TODO Auto-generated method stub
			dao.save(customer);
			return customer;
		}
		
		
	    
	    //Add the Customer Details and save them 
	    /*
	     * 
	     Connection Service Class implemented by 
	     @Author: Danish Shaikh
	     @Version:1.0
	     @Since: 11-05-2019
	     */
	    
	  
	
	
	

/*    ConnectionDaoImp dao;
    
    public ConnectionServiceImp()
    {
    	dao=new ConnectionDaoImp();
    }
	

	public Customer add(Customer customer) {
		// TODO Auto-generated method stub
	
		return dao.save(customer);
	}
*/
	

}
