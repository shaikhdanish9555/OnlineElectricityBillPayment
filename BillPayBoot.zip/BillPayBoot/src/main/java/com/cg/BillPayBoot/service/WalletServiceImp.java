package com.cg.BillPayBoot.service;

import com.cg.BillPayBoot.dao.WalletDao;
import com.cg.BillPayBoot.dto.*;

import java.math.BigDecimal;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/*
 * 
 Wallet Service Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

@Service
@Transactional
public class WalletServiceImp implements WalletService{

@Autowired
 WalletDao da;

	
	public Wallet addMoney(Wallet ad) {
	// TODO Auto-generated method stub
	return da.save(ad);
}


	public Wallet showBalance(int id) {
		return da.findByid(id);
		
	
	}

}

	
	
	/*public WalletServiceImp()*/
		/* {
	}
		
		da=new WalletDaoImp();
	}*/

	
	//Adding Money to the Wallet
	/*
	 * 
	 Wallet Service Class implemented by 
	 @Author: Danish Shaikh
	 @Version:1.0
	 @Since: 11-05-2019
	 */
	

	
	/*
	 * 
	 Wallet Service Class implemented by 
	 @Author: Danish Shaikh
	 @Version:1.0
	 @Since: 11-05-2019
	 */
	
	
	//Show the Available Balance of the Wallet
		// TODO Auto-generated method stub
		/*Wallet wall=da.showTopupbalance(id);
		if(wall!=null)
		{
			return wall;	
			
		}
		else
		{
			System.out.println("Balance is Not Available");	
		}*/
