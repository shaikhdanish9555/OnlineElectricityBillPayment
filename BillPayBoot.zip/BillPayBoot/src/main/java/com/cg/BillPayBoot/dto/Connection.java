package com.cg.BillPayBoot.dto;


import java.math.BigDecimal;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.cg.BillPayBoot.dto.Customer;


/*
 * 
 Connection DTO Class implemented by 
 @Author: Danish Shaikh
 @Version:1.0
 @Since: 11-05-2019
 */

@Entity
@Table(name="connection")
public class Connection {
	
	@Id
	@Column(name="consumer_num")
	private BigInteger consumerNumber;
	 
	@Column(name="billing_unit")
	private int billingUnit;
	 

	 
	@Column(name="type")
	private String type; 

	
	public Connection()
	{
		
	}

	
  public BigInteger getConsumerNumber() {
		return consumerNumber;
	}

  public void setConsumerNumber(BigInteger consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

  public int getBillingUnit() {
		return billingUnit;
	}

   public void setBillingUnit(int billingUnit) {
		this.billingUnit = billingUnit;
	}

	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	

	@Override
	public String toString() {
		return "Connection [consumerNumber=" + consumerNumber + ", billingUnit=" + billingUnit + ", type=" + type + "]";
	}


	

		
}







/*@Component
public class Connection {
	
	private BigInteger consumerNumber;
	private int billingUnit;
	BigDecimal amount;
	private String type; 

	
	public Connection()
	{
		
	}

	
	 public Connection(BigInteger consumerNumber, int billingUnit, BigDecimal amount, String type) {
		super();
		this.consumerNumber = consumerNumber;
		this.billingUnit = billingUnit;
		this.amount = amount;
		this.type = type;
	}


  public BigInteger getConsumerNumber() {
		return consumerNumber;
	}

  public void setConsumerNumber(BigInteger consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

  public int getBillingUnit() {
		return billingUnit;
	}

   public void setBillingUnit(int billingUnit) {
		this.billingUnit = billingUnit;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Connection [consumerNumber=" + consumerNumber + ", billingUnit=" + billingUnit + ", amount=" + amount
				+ ", type=" + type + "]";
	}

		
}
*/


