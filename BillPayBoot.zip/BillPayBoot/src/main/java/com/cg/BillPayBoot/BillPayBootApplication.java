package com.cg.BillPayBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.BillPayBoot")
public class BillPayBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillPayBootApplication.class, args);
	
		System.out.println("This is Online Electricity Bill Payment Project....");
		
	}

}
