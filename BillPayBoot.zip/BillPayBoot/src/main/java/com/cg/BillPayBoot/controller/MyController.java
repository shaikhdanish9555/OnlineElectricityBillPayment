package com.cg.BillPayBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.BillPayBoot.dto.Customer;
import com.cg.BillPayBoot.dto.Wallet;
import com.cg.BillPayBoot.service.ConnectionService;
import com.cg.BillPayBoot.service.TransactionService;
import com.cg.BillPayBoot.service.WalletService;


@RestController
@RequestMapping("/billpayboot")
public class MyController {

	@Autowired
	ConnectionService connectionservice;

	@Autowired
	TransactionService transactionservice;
	
	@Autowired
	WalletService walletservice;
	
	
/*	@RequestMapping(value="/checkname/{uname}",method=RequestMethod.GET)
	//@GetMapping("checkname")
	public String getName(@PathVariable("uname")String mname,@RequestParam("prodid")String id) {
		System.out.println("helooooo");
		return id+"Capgemini" +mname;
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value="/checkname")
	public String getData(@RequestParam("prodid")String pid,@RequestParam("prodName")String name,@RequestParam("prodPrice")String pprice) {
		
		System.out.println(pid+""+name+""+pprice+"");
		return "Welcome";
	}
	*/
	
	@RequestMapping(value="/addcustomer",method=RequestMethod.POST)
	public ResponseEntity<Customer> addcustomer(@ModelAttribute Customer customer) {
		Customer cust=connectionservice.add(customer);
		if(cust==null){
			return new ResponseEntity("Customer not Added",HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity<Customer>(cust,HttpStatus.OK);
	}
	
	//**************************************************************
	
	@RequestMapping(value="/addwallet",method=RequestMethod.POST)
	public ResponseEntity<Wallet> addcustomer(@ModelAttribute Wallet wall) {
		
		
		Wallet wall1=walletservice.addMoney(wall);
		if(wall1==null){
			return new ResponseEntity("Wallet not Added",HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity<Wallet>(wall1,HttpStatus.OK);
	}
	
	//**************************************************************************
	
	@RequestMapping(value="/showwallet",method=RequestMethod.POST)
	public ResponseEntity<Wallet> showWallet(@ModelAttribute Wallet wall) {
		
		
		Wallet wall1=walletservice.showBalance(wall.getId());
		if(wall1==null){
			return new ResponseEntity("Wallet not Added",HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity<Wallet>(wall1,HttpStatus.OK);
	}
	
	//***************************************************************************
	
	
	@RequestMapping(value="/paybills",method=RequestMethod.POST)
	public ResponseEntity<Wallet> paybill(@ModelAttribute Wallet wall) {
		
		
		transactionservice.lastTransaction(wall);
		return null;
	}
		/*if(wall1==null){
			return new ResponseEntity("Wallet not Added",HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity<Wallet>(wall1,HttpStatus.OK);
	}
	
	
	/*@RequestMapping(value="/show",method=RequestMethod.GET)
	public ResponseEntity<List<Product>> showAllProduct(){
		List<Product> myList=productservice.showAll();
		if(myList.isEmpty()) {
			return new ResponseEntity("No product for show",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
	}
	
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public ResponseEntity<List<Product>> searchProduct(@RequestParam("name")String name){
		//System.out.println(id);
		//int a=Integer.parseInt(id);
		List<Product> pro1=productservice.findByname(name);
		
		if(pro1.isEmpty()) {
			return new ResponseEntity("No product for show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(pro1,HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/searchbyrange",method=RequestMethod.POST)
	public ResponseEntity<List<Product>> searchProduct(@RequestParam("min")double priceOne,@RequestParam("max")double priceTwo ){
		//System.out.println(id);
		//int a=Integer.parseInt(id);
		List<Product> pro1=productservice.findByPriceBetween(priceOne, priceTwo);
		return new ResponseEntity<List<Product>>(pro1,HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/addall",method=RequestMethod.POST)
	public ResponseEntity<Product> addAll(@ModelAttribute Product prod) {
	*/
		/*
		@RequestParam("id") int pid,
		@RequestParam("name") String name,
		@RequestParam("price") double price,
		@RequestParam("desc") String desc,
		@RequestParam("inid") int inid,
		@RequestParam("inname") String inname*/
		
		/*	
		Inventory inventory=new Inventory();
		inventory.setId(inid);
inventory.setName(inname);

		Product prod=new Product();
		prod.setId(pid);
		prod.setName(name);
		prod.setPrice(price);
		prod.setDescription(desc);
		prod.setInventory(inventory);*/
				
	/*			Product pro=productservice.addProduct(prod);
		if(pro==null){
			return new ResponseEntity("Producr notnadeed",HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity<Product>(pro,HttpStatus.OK);
	}
	*/
	
/*	@RequestMapping(value="/update",method=RequestMethod.PUT)
	public Product updateProduct(@RequestParam("id")int id,@RequestBody Product product){
		//System.out.println(id);
		//int a=Integer.parseInt(id);
		//System.out.println(productservice.searchbyid(a));
		Product pro=productservice.searchbyid(id);
		pro.setPrice(product.getPrice());
		
		
		
		return productservice.addProduct(pro); */
			

}
