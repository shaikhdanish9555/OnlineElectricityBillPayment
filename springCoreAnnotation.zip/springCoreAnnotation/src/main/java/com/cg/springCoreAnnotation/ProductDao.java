package com.cg.springCoreAnnotation;

import java.util.List;

public interface ProductDao {
	
	public void save(Product pro);
	
	public List<Product> showAll();

}
