package com.cg.springCoreAnnotation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("productservice")
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao productdao;
	
	public void addProduct(Product prod) {
		
		productdao.save(prod);
		
		
	}

	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
