package com.cg.springCoreAnnotation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;


@Repository("ProductDao")
public class ProductDaoImpl implements ProductDao{

	List<Product> productList = new ArrayList<Product>();
	
	public void save(Product pro) {
		
		productList.add(pro);
		
	}

	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return productList;
	}
	

}
