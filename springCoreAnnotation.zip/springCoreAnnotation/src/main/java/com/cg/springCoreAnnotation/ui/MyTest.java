package com.cg.springCoreAnnotation.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.springCoreAnnotation.Product;
import com.cg.springCoreAnnotation.ProductService;
import com.cg.springCoreAnnotation.Transaction;
import com.cg.springCoreAnnotation.config.JavaConfig;


public class MyTest {

	@Autowired
	static ProductService productservice;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfigApplicationContext app = new AnnotationConfigApplicationContext(JavaConfig.class);
		
		Product myProduct = (Product) app.getBean("Prod");
		
		Transaction myTransaction = (Transaction) app.getBean("tran");
		
		myProduct.setId(1001);
		myProduct.setName("Fastrack");
		myProduct.setPrice(5000.00);
		myProduct.setDescription("Good......");
		
		myTransaction.setId(101);
		myTransaction.setAmount(500.00);
		myTransaction.setdescrption("For Product 1001.....");
		
		productservice.addProduct(myProduct);
		
		productservice.showAll();
	
	}

}
