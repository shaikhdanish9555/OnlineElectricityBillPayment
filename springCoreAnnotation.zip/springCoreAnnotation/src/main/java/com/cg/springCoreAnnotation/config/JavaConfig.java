package com.cg.springCoreAnnotation.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.springCoreAnnotation.Product;
import com.cg.springCoreAnnotation.Transaction;

@Configuration
@ComponentScan("com.cg.springCoreAnnotation")
public class JavaConfig {

	
}