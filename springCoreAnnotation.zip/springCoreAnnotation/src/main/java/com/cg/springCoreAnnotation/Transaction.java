package com.cg.springCoreAnnotation;

public class Transaction {
	
	private int id;
	private double amount;
	private String descrption;
	
	public Transaction() {
		
	}

	public Transaction(int id, double amount, String descrption) {
		super();
		this.id = id;
		this.amount = amount;
		this.descrption = descrption;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getdescrption() {
		return descrption;
	}

	public void setdescrption(String descrption) {
		descrption = descrption;
	}

	@Override
	public String toString() {
		return "Transaction [id=" + id + ", amount=" + amount + ", Annotation=" + descrption + "]";
	}
	
	
	
	
}
